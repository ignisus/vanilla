If using Paper/Spigot, use 'griefdefender-bukkit-2.4.7.jar'
If using Sponge, due to spigot file limitations you will need to join discord to access the download in #sponge-releases.
Note: All discord invites are sent to PayPal email used to purchase.
Note: Check junk/spam email if you do not see a discord invite.
Note: If you are unable to access discord, email me at kanesoftware@outlook.com for a new link.

If you have any issues with install, see wiki for help
https://docs.griefdefender.com/wiki/

Note: If you copy the wrong platform jar to your server, GriefDefender will NOT load.
Note: If you are using spark and having GD boot problems, update to latest here https://ci.lucko.me/job/spark/

IMPORTANT:

If you are upgrading from 1.5.X, it is important to take a full backup of all your GriefDefender and LuckPerms data before proceeding with update.
If you were using built-in hooks in 1.5.X for external plugins, most have been moved to the official addon GDHooks. See https://github.com/bloodmc/GDHooks for more information.

Note: If you have substantial changes to configs, it is recommended to make these changes on a test server then copying the new configs to production server.

Bukkit
------
1. Delete the language folder in ./plugins/griefdefender/lang
2. Delete the lib folder in ./plugins/griefdefender/lib
3. Backup global.conf, flags.conf, options.conf in ./plugins/griefdefender
4. Delete global.conf, flags.conf, and options.conf.
5. Transfer any settings from step 3 to newly generated files. (Requires at least 1 startup)

Note: This version requires LuckPerms 5.3.98+ or GriefDefender may not function properly. You can find the latest LuckPerms version at https://luckperms.net

Sponge
------
1. Delete the language folder in ./config/griefdefender/lang
2. Delete the lib folder in ./config/griefdefender/lib
3. Backup global.conf, flags.conf, options.conf in ./config/griefdefender
4. Delete global.conf, flags.conf, and options.conf.
5. Transfer any settings from step 3 to newly generated files. (Requires at least 1 startup)

Note: This version requires LuckPerms 5.3.98 or GriefDefender will NOT function properly. You can find this sponge version here : https://ore.spongepowered.org/Luck/LuckPerms/versions/5.3.98